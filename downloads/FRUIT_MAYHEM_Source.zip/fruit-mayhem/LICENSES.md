# Licenses

The GDScript source, original procedural geometry, generated textures, and synthesized audio in this project are available under the MIT license below. There are no downloaded third-party art or sound assets.

Copyright (c) 2026 FRUIT MAYHEM contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Godot engine

Godot 4.6.3 is MIT licensed. The Windows export contains the Godot engine and its bundled libraries. Engine license and third-party notices are supplied in GODOT_LICENSE.txt and GODOT_COPYRIGHT.txt. Full license information: https://godotengine.org/license/ . Godot's logo belongs to the Godot project.
