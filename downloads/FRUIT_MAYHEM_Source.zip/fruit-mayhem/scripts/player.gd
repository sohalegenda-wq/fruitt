class_name SandboxPlayer
extends CharacterBody3D

var game: Node3D
var pivot: Node3D
var camera: Camera3D
var held: RigidBody3D
var vehicle: PlayProp
var third_person = false
var photo = false
var step_timer = 0.0
var pitch = -.10
var tool_model: Node3D
var avatar: Node3D
var avatar_limbs: Array[MeshInstance3D] = []

func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	var col = CollisionShape3D.new()
	var shape = CapsuleShape3D.new()
	shape.radius = .32
	shape.height = 1.75
	col.shape = shape
	col.position.y = .88
	add_child(col)
	avatar = Art.fruit(0)
	avatar.position.y = 1.3
	avatar.rotation.y = PI
	avatar.visible = false
	add_child(avatar)
	for side in [-1,1]:
		avatar_limbs.append(Art.sphere(avatar,Vector3(side*.78,-.24,0),Vector3(.12,.35,.12),Art.material(Color("303e55"))))
		Art.sphere(avatar,Vector3(side*.79,-.50,0),Vector3.ONE*.16,Art.material(Color("fff1d6")))
		avatar_limbs.append(Art.sphere(avatar,Vector3(side*.3,-.88,0),Vector3(.12,.34,.12),Art.material(Color("303e55"))))
		Art.sphere(avatar,Vector3(side*.3,-1.15,.10),Vector3(.18,.14,.24),Art.material(Color("303e55")))
	pivot = Node3D.new()
	pivot.position.y = 1.6
	add_child(pivot)
	camera = Camera3D.new()
	camera.fov = 78
	camera.far = 160
	pivot.add_child(camera)
	tool_model = Node3D.new()
	camera.add_child(tool_model)
	tool_model.position = Vector3(.38,-.30,-.65)
	Art.cylinder(tool_model,Vector3.ZERO,.09,.32,Art.material(Color("24394b"),.6)).rotation.x = PI/2
	Art.cylinder(tool_model,Vector3(0,0,-.2),.13,.12,Art.material(Color("f4b64f"),.5)).rotation.x = PI/2
	Art.sphere(tool_model,Vector3(0,0,-.28),Vector3(.07,.07,.045),Art.glow(Color("75f4d3")))
	Art.box(tool_model,Vector3(0,-.10,.08),Vector3(.12,.22,.12),Art.material(Color("344957")))

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:
		rotation.y -= event.relative.x*game.sensitivity
		pitch = clampf(pitch-event.relative.y*game.sensitivity,-1.45,1.45)
		pivot.rotation.x = pitch
	if game.ui.is_open(): return
	if event.is_action_pressed("grab"): grab()
	if event.is_action_pressed("drop"): held = null
	if event.is_action_pressed("interact"): interact()
	if event.is_action_pressed("view"):
		third_person = not third_person
		avatar.visible = third_person
		camera.position = Vector3(0,1.3,4) if third_person else Vector3.ZERO
	if event.is_action_pressed("photo"):
		photo = not photo
		collision_mask = 0 if photo else 1
		game.toast("PHOTO CAMERA · WASD / Space / Ctrl · F12 screenshot" if photo else "Player camera")
	if event.is_action_pressed("shoot"): use_tool(false)
	if event.is_action_pressed("alt"): use_tool(true)
	if event.is_action_pressed("reset_tool"):
		if is_instance_valid(held) and held is FruitNPC: held.recover()
		else: game.tool = 0
	if event.is_action_pressed("rotate") and is_instance_valid(held): held.rotate_y(PI/8)
	if event.is_action_pressed("delete"):
		var hit = ray()
		if hit and hit.collider.is_in_group("saveable"): hit.collider.queue_free()
	if event.is_action_pressed("screenshot"): game.screenshot()

func _physics_process(delta: float) -> void:
	if game.ui.is_open(): return
	for i in range(avatar_limbs.size()):
		avatar_limbs[i].rotation.x = sin(Time.get_ticks_msec()*.008+i*PI)*minf(velocity.length()*.06,.45)
	if is_instance_valid(vehicle):
		global_position = vehicle.global_position+Vector3(0,1,0)
		return
	var input = Input.get_vector("left","right","forward","back")
	var direction = (global_basis*Vector3(input.x,0,input.y)).normalized()
	var speed = 9.0 if Input.is_action_pressed("sprint") else 5.2
	if photo:
		direction = (pivot.global_basis*Vector3(input.x,0,input.y)).normalized()
		direction.y += float(Input.is_action_pressed("jump"))-float(Input.is_action_pressed("crouch"))
		velocity = direction*speed*1.6
	else:
		velocity.x = move_toward(velocity.x,direction.x*speed,delta*25)
		velocity.z = move_toward(velocity.z,direction.z*speed,delta*25)
		if not is_on_floor(): velocity.y -= 12*game.gravity_factor*delta
		if Input.is_action_just_pressed("jump") and is_on_floor():
			velocity.y = 6.5
			game.sound("jump",global_position)
		var crouch = Input.is_action_pressed("crouch")
		pivot.position.y = lerpf(pivot.position.y,1.0 if crouch else 1.6,delta*10)
		if crouch: velocity.x *= .55; velocity.z *= .55
		step_timer -= delta
		if is_on_floor() and direction.length()>.1 and step_timer<=0:
			step_timer = .3 if speed>6 else .45
			game.sound("step",global_position,.8+randf()*.3,.35)
	move_and_slide()
	if global_position.y < -15:
		global_position = Vector3(0,3,12)
		velocity = Vector3.ZERO
	if is_instance_valid(held):
		if held.freeze: held.freeze = false
		var point = camera.global_position-camera.global_basis.z*3.8
		held.apply_central_force(((point-held.global_position)*18-held.linear_velocity*6)*held.mass)
		held.angular_velocity *= .90
		if point.distance_to(held.global_position)>12: held = null
	tool_model.visible = not photo
	tool_model.rotation.z = sin(Time.get_ticks_msec()*.003)*.025

func ray(distance: float = 45) -> Dictionary:
	var origin = camera.global_position
	var query = PhysicsRayQueryParameters3D.create(origin,origin-camera.global_basis.z*distance,3,[get_rid()])
	return get_world_3d().direct_space_state.intersect_ray(query)

func grab() -> void:
	if is_instance_valid(held):
		held = null
		return
	var hit = ray(10)
	if hit and hit.collider is RigidBody3D:
		held = hit.collider
		if held is FruitNPC:
			held.set_frozen(false)
			held.knock(Vector3.ZERO)
		game.sound("click",held.global_position)

func interact() -> void:
	if is_instance_valid(vehicle):
		vehicle.driven = false
		global_position = vehicle.global_position+Vector3(2.4,1,0)
		vehicle = null
		return
	var hit = ray(6)
	if hit and hit.collider is PlayProp and hit.collider.kind=="Car":
		vehicle = hit.collider
		vehicle.driven = true
		game.toast("WASD drive · E exit")
	elif hit and hit.collider is FruitNPC:
		hit.collider.recover()
		hit.collider.mood = FruitNPC.Mood.HAPPY
		hit.collider.emotion_time = 3
		game.sound("voice",hit.position,1.2)

func spawn_position() -> Vector3:
	var hit = ray(12)
	if hit: return hit.position+Vector3.UP*1.6
	return global_position-global_basis.z*5+Vector3.UP*2

func use_tool(alternate: bool) -> void:
	var hit = ray()
	var direction = -camera.global_basis.z
	if game.tool==0 and alternate:
		game.shockwave(global_position+direction*4)
		return
	if game.tool==6:
		var p = game.spawn_prop("Ball",camera.global_position+direction*2)
		if p:
			p.apply_central_impulse(direction*22)
			game.sound("pulse",camera.global_position)
		return
	if not hit: return
	var body = hit.collider
	match game.tool:
		0:
			if body is FruitNPC: body.knock(direction*body.mass*12+Vector3.UP*body.mass*4)
			elif body is RigidBody3D: body.apply_central_impulse(direction*body.mass*12)
			game.burst(hit.position,Color("7beed8"))
		1:
			if alternate:
				if is_instance_valid(held): held.apply_central_impulse(direction*held.mass*22); held = null
			else: grab()
		2:
			if body is FruitNPC: body.set_frozen(not body.frozen)
			elif body is RigidBody3D: body.freeze = not body.freeze
		3:
			if body is FruitNPC:
				body.resize(.7 if alternate else 1.6)
				game.burst(hit.position,Color("d3a5ff"))
		4:
			if body is FruitNPC:
				body.set_frozen(false)
				body.knock(Vector3.UP*body.mass*2)
				body.bubble_timer = 0 if alternate else 4
		5:
			if alternate: game.teleport_marker = hit.position+Vector3.UP*1.8; game.toast("Teleport destination set")
			elif body is RigidBody3D:
				body.global_position = game.teleport_marker
				body.linear_velocity = Vector3.ZERO
		7:
			game.shockwave(hit.position, -1 if alternate else 1)
	game.sound("pulse",hit.position,1.3 if game.tool==2 else .9)
