class_name PlayProp
extends RigidBody3D

var kind = "Crate"
var game: Node3D
var hp = 3
var hit_timer = 0.0
var driven = false

func _ready() -> void:
	add_to_group("prop")
	add_to_group("saveable")
	mass = 3
	contact_monitor = true
	max_contacts_reported = 4
	continuous_cd = true
	var col = CollisionShape3D.new()
	var mat = PhysicsMaterial.new()
	mat.friction = .65
	mat.bounce = .15
	physics_material_override = mat
	match kind:
		"Ball", "Metal ball":
			var shape = SphereShape3D.new()
			shape.radius = .55
			col.shape = shape
			Art.sphere(self,Vector3.ZERO,Vector3.ONE*.55,Art.material(Color("5cdac7") if kind=="Ball" else Color("94a8b6"),.0 if kind=="Ball" else .85))
			mass = 1 if kind=="Ball" else 12
			mat.bounce = .82 if kind=="Ball" else .3
		"Barrel":
			var shape = CylinderShape3D.new()
			shape.height = 1.4
			shape.radius = .48
			col.shape = shape
			Art.cylinder(self,Vector3.ZERO,.48,1.4,Art.material(Color("f4b44d"),.35))
			for y in [-.49,.49]: Art.cylinder(self,Vector3(0,y,0),.50,.09,Art.material(Color("354b5a"),.65))
			Art.label(self,"JUICE",Vector3(0,.1,.49),22,Color("24334c"))
		"Car":
			var shape = BoxShape3D.new()
			shape.size = Vector3(1.7,.8,2.7)
			col.shape = shape
			mass = 25
			Art.box(self,Vector3.ZERO,shape.size,Art.material(Color("f76e62"),.3))
			Art.box(self,Vector3(0,.58,-.2),Vector3(1.35,.65,1.3),Art.material(Color("69bdcf"),.5))
			for x in [-.95,.95]:
				for z in [-.9,.9]:
					var wheel = Art.cylinder(self,Vector3(x,-.35,z),.39,.24,Art.material(Color("263447")))
					wheel.rotation.z = PI/2
					var lamp = Art.sphere(self,Vector3(x*.65,.08,1.39),Vector3(.18,.10,.04),Art.glow(Color("ffe4a0")))
					lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			lock_rotation = true
		"Plank":
			var shape = BoxShape3D.new()
			shape.size = Vector3(3,.22,.65)
			col.shape = shape
			Art.box(self,Vector3.ZERO,shape.size,Art.material(Color("c69b68")))
		"Spring":
			var shape = BoxShape3D.new()
			shape.size = Vector3(1,.5,1)
			col.shape = shape
			for i in range(10):
				var a = i*1.8
				Art.sphere(self,Vector3(cos(a)*.32,-.2+i*.045,sin(a)*.32),Vector3(.10,.07,.10),Art.material(Color("7bc8e6"),.7))
			Art.box(self,Vector3(0,.28,0),Vector3(1,.12,1),Art.material(Color("f3be65")))
			mat.bounce = .95
		_:
			var shape = BoxShape3D.new()
			shape.size = Vector3.ONE*1.1
			col.shape = shape
			Art.box(self,Vector3.ZERO,shape.size,Art.material(Color("ba8656")))
			for z in [-.57,.57]:
				for x in [-.42,.42]: Art.box(self,Vector3(x,0,z),Vector3(.13,1.18,.08),Art.material(Color("eac48a")))
			for y in [-.46,.46]: Art.box(self,Vector3(0,y,.58),Vector3(1.14,.14,.07),Art.material(Color("efd1a1")))
	add_child(col)
	body_entered.connect(on_hit)

func _physics_process(delta: float) -> void:
	hit_timer = maxf(0,hit_timer-delta)
	if global_position.y < -25: queue_free()
	if kind=="Car" and driven:
		var throttle = Input.get_axis("back","forward")
		var steer = Input.get_axis("right","left")
		rotation.y += steer*delta*1.5*clampf(linear_velocity.length()/3,.3,1)
		apply_central_force(global_basis.z*throttle*mass*14)
		linear_damp = 1.0

func on_hit(_body: Node) -> void:
	if linear_velocity.length() > 7 and hit_timer <= 0:
		hit_timer = .5
		hp -= 1
		game.sound("impact",global_position)
		if kind=="Crate" and hp<=0:
			game.burst(global_position,Color("e2b788"))
			for i in range(4):
				if game.get_tree().get_nodes_in_group("saveable").size()<game.body_limit:
					var p = game.spawn_prop("Plank",global_position+Vector3(randf()-.5,randf(),randf()-.5))
					p.apply_central_impulse(Vector3(randf_range(-4,4),3,randf_range(-4,4)))
			queue_free()

func snapshot() -> Dictionary:
	return {"type":"prop","kind":kind,"pos":[position.x,position.y,position.z],"yaw":rotation.y,"frozen":freeze}
