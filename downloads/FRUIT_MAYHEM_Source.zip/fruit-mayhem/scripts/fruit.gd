class_name FruitNPC
extends RigidBody3D

enum Mood { IDLE, WANDER, CURIOUS, HAPPY, AFRAID, ANGRY, CHASE, RAGDOLL, RECOVER }
var kind: int = 0
var mood: Mood = Mood.WANDER
var game: Node3D
var skin: Node3D
var anatomy: Node3D
var limbs: Array[RigidBody3D] = []
var rest: Array[Vector3] = []
var joints: Array[PinJoint3D] = []
var target = Vector3.ZERO
var think_timer = 0.0
var tumble_timer = 0.0
var hit_cooldown = 0.0
var phase = 0.0
var frozen = false
var giant = false
var scored = false
var bubble_timer = 0.0
var bubble: MeshInstance3D
var xray = false
var original_materials: Dictionary = {}
var size_factor = 1.0
var emotion_time = 0.0

func _ready() -> void:
	add_to_group("fruit")
	add_to_group("saveable")
	mass = [3.0,2.0,7.0,2.5,2.0,3.0,4.0,2.0,1.5,2.5][kind]
	lock_rotation = true
	linear_damp = 1.4
	angular_damp = 2.0
	contact_monitor = true
	max_contacts_reported = 6
	continuous_cd = true
	var pm = PhysicsMaterial.new()
	pm.friction = .85
	pm.bounce = .18
	physics_material_override = pm
	var shape = CollisionShape3D.new()
	var ball = SphereShape3D.new()
	ball.radius = .72 if kind != 2 else .97
	shape.shape = ball
	shape.position.y = -.45
	add_child(shape)
	skin = Art.fruit(kind)
	add_child(skin)
	# Distance detail reduction supplements the engine's automatic frustum culling.
	for detail in skin.get_children():
		if detail is GeometryInstance3D:
			detail.visibility_range_end = 33 if detail != skin.get_child(0) and kind!=9 else 95
			detail.visibility_range_end_margin = 3
	anatomy = Art.interior()
	add_child(anatomy)
	anatomy.visible = false
	for i in range(4):
		make_limb(i)
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(.35,.85,1,.18)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bubble = Art.sphere(self,Vector3.ZERO,Vector3.ONE*1.4,mat)
	bubble.visible = false
	body_entered.connect(on_collision)
	choose_target()
	phase = randf()*TAU

func make_limb(index: int) -> void:
	var arm = index < 2
	var side = -1.0 if index%2==0 else 1.0
	var offset = Vector3(side*(.78 if arm else .30),-.20 if arm else -.86,0)
	var part = RigidBody3D.new()
	part.name = "Limb%d" % index
	part.mass = .25
	part.freeze = true
	part.freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
	part.collision_layer = 2
	part.collision_mask = 1
	part.top_level = true
	add_child(part)
	var col = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = .11
	capsule.height = .52
	col.shape = capsule
	part.add_child(col)
	var mesh = CapsuleMesh.new()
	mesh.radius = .10
	mesh.height = .52
	mesh.radial_segments = 12
	mesh.rings = 4
	Art.mesh(part,mesh,Vector3.ZERO,Art.material(Color("303e55")))
	Art.sphere(part,Vector3(0,-.26,.04 if arm else .09),Vector3(.17,.15,.15 if arm else .24),Art.material(Color("fff1d6") if arm else Color("24334c")))
	part.add_collision_exception_with(self)
	for other in limbs: part.add_collision_exception_with(other)
	limbs.append(part)
	rest.append(offset)
	part.global_transform = global_transform * Transform3D(Basis.IDENTITY,offset)
	var joint = PinJoint3D.new()
	joint.position = offset+Vector3(0,.22,0)
	add_child(joint)
	joints.append(joint)
	joint.set_param(PinJoint3D.PARAM_BIAS,.6)

func _physics_process(delta: float) -> void:
	phase += delta*5
	hit_cooldown = maxf(0,hit_cooldown-delta)
	if global_position.y < -18:
		global_position = Vector3(randf_range(-5,5),4,randf_range(-5,5))
		linear_velocity = Vector3.ZERO
	if frozen: return
	if bubble_timer > 0:
		bubble_timer -= delta
		apply_central_force(Vector3.UP*mass*16)
		bubble.visible = true
	else: bubble.visible = false
	if mood == Mood.RAGDOLL:
		tumble_timer -= delta
		if tumble_timer < 0 and linear_velocity.length()<3.0: recover()
		return
	if mood == Mood.RECOVER:
		mood = Mood.HAPPY
		emotion_time = 2
	var distance = global_position.distance_to(game.player.global_position)
	if distance > 40:
		linear_damp = 4
		return
	linear_damp = 1.4
	emotion_time = maxf(0,emotion_time-delta)
	if mood in [Mood.AFRAID,Mood.ANGRY,Mood.CHASE,Mood.HAPPY] and emotion_time<=0:
		mood = Mood.WANDER
		choose_target()
	if mood==Mood.CHASE: target=game.player.global_position
	think_timer -= delta
	if think_timer < 0:
		think_timer = randf_range(1.4,3.4)
		if mood==Mood.ANGRY:
			mood=Mood.CHASE
			emotion_time=3.5
		elif distance<2.2 and game.player.velocity.length()>4:
			mood=Mood.ANGRY
			emotion_time=3
		elif global_position.distance_to(target)<2 or randf()<.25: choose_target()
		if distance < 4 and randf()<.6:
			mood = Mood.CURIOUS
			target = game.player.global_position
		elif mood not in [Mood.AFRAID,Mood.ANGRY,Mood.CHASE]: mood = Mood.WANDER if randf()>.2 else Mood.IDLE
		if mood==Mood.WANDER and randf()<.2:
			var props = get_tree().get_nodes_in_group("prop")
			if props.size()>0:
				target=props.pick_random().position
				mood=Mood.CURIOUS
		if randf()<.08: game.sound("voice",global_position,randf_range(.7,1.4))
	var dir = target-global_position
	dir.y = 0
	if dir.length()>1.2 and mood != Mood.IDLE:
		dir = dir.normalized()
		# Ahead ray detects walls and props; turn toward another destination.
		var q = PhysicsRayQueryParameters3D.create(global_position,global_position+dir*1.9,1,[get_rid()])
		if get_world_3d().direct_space_state.intersect_ray(q):
			choose_target()
			dir = dir.rotated(Vector3.UP,1.3)
		var speed = 1.25 if mood not in [Mood.AFRAID,Mood.CHASE] else 3.5
		if distance < 2.7 and mood == Mood.CURIOUS: speed = .0
		apply_central_force((dir*speed-Vector3(linear_velocity.x,0,linear_velocity.z))*mass*20)
		rotation.y = lerp_angle(rotation.y,atan2(dir.x,dir.z),delta*3)
	for i in range(limbs.size()):
		var swing = sin(phase+(i%2)*PI)*minf(linear_velocity.length()*.22,.6)
		var basis = global_basis * Basis(Vector3.RIGHT,swing)
		limbs[i].global_transform = Transform3D(basis,global_transform*rest[i])

func choose_target() -> void:
	target = Vector3(randf_range(-20,20),0,randf_range(-20,20))
	# Keep NPCs on solid ground in all three bounded maps.

func on_collision(_body: Node) -> void:
	if hit_cooldown > 0: return
	if linear_velocity.length() > 5.7:
		knock(Vector3.ZERO)

func knock(impulse: Vector3) -> void:
	if frozen: return
	if mood != Mood.RAGDOLL:
		mood = Mood.RAGDOLL
		lock_rotation = false
		for i in range(joints.size()):
			joints[i].node_a = joints[i].get_path_to(self)
			joints[i].node_b = joints[i].get_path_to(limbs[i])
		for part in limbs:
			part.freeze = false
			part.linear_velocity = linear_velocity
		tumble_timer = 4.5
		for other in get_tree().get_nodes_in_group("fruit"):
			if other!=self and other.mood!=Mood.RAGDOLL and other.position.distance_to(position)<7:
				other.mood=Mood.AFRAID
				other.emotion_time=3
				other.target=other.position+(other.position-position).normalized()*8
		if hit_cooldown <= 0:
			game.burst(global_position,Art.COLORS[kind])
			game.sound("juice",global_position)
			hit_cooldown = .8
	apply_central_impulse(impulse)
	apply_torque_impulse(Vector3(randf_range(-1,1),.3,randf_range(-1,1))*2)

func recover() -> void:
	mood = Mood.RECOVER
	lock_rotation = true
	rotation = Vector3(0,rotation.y,0)
	global_position.y = maxf(1.45*size_factor,global_position.y+.6)
	angular_velocity = Vector3.ZERO
	for joint in joints:
		joint.node_a = NodePath()
		joint.node_b = NodePath()
	for part in limbs:
		part.freeze = true
	game.sound("voice",global_position,1.3)
	choose_target()

func set_frozen(value: bool) -> void:
	frozen = value
	freeze = value
	for part in limbs: part.freeze = value or mood != Mood.RAGDOLL
	if value: game.sound("freeze",global_position)
	bubble.visible = value

func set_xray(value: bool) -> void:
	xray = value
	anatomy.visible = value
	for child in skin.get_children():
		if child is MeshInstance3D:
			if not original_materials.has(child): original_materials[child] = child.material_override
			if value:
				var ghost = original_materials[child].duplicate() as StandardMaterial3D
				ghost.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
				ghost.albedo_color.a = .13
				ghost.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
				child.material_override = ghost
			else: child.material_override = original_materials[child]

func resize(value: float) -> void:
	# Uniform scale applies to body, anatomy and joint anchors.
	size_factor = clampf(value,.6,1.65)
	scale = Vector3.ONE*size_factor
	giant = size_factor > 1.1
	for p in limbs: p.scale = Vector3.ONE*size_factor

func snapshot() -> Dictionary:
	return {"type":"fruit","kind":kind,"pos":[position.x,position.y,position.z],"size":size_factor,"frozen":frozen}
