class_name MayhemUI
extends CanvasLayer

var game: Node3D
var root: Control
var screen: PanelContainer
var hud: Control
var hint: Label
var stats: Label
var tool_label: Label
var toast_label: Label
var toast_timer = 0.0
var page = ""
var preview: SubViewport
var preview_root: Node3D
var preview_model: Node3D
var selected_kind = 0
var pending_action = ""
var loading_progress: ProgressBar
var spawn_category = "FRUIT"
const INK = Color("132b3a")
const CREAM = Color("f7edce")
const MINT = Color("8de2bc")
const AMBER = Color("f1bc65")

func _ready() -> void:
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	var theme = Theme.new()
	theme.default_font_size = 18
	theme.set_color("font_color","Label",CREAM)
	root.theme = theme
	make_hud()

func style(color: Color, border: Color = Color.TRANSPARENT, radius: int = 12) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = color
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 11
	s.content_margin_bottom = 11
	return s

func text(parent: Node, value: String, size: int = 18, color: Color = CREAM) -> Label:
	var l = Label.new()
	l.text = value
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",color)
	parent.add_child(l)
	return l

func button(parent: Node, value: String, callback: Callable, primary: bool = false) -> Button:
	var b = Button.new()
	b.text = value
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(0,46)
	b.add_theme_stylebox_override("normal",style(MINT if primary else Color("203e4e"),Color("456171")))
	b.add_theme_stylebox_override("hover",style(AMBER))
	b.add_theme_stylebox_override("pressed",style(Color("d99c51")))
	b.add_theme_stylebox_override("focus",style(Color.TRANSPARENT,MINT))
	for state in ["font_color","font_hover_color","font_pressed_color"]: b.add_theme_color_override(state,INK if primary or state!="font_color" else CREAM)
	b.add_theme_font_size_override("font_size",17)
	parent.add_child(b)
	b.pressed.connect(func(): game.sound("click",Vector3.ZERO); callback.call())
	return b

func make_hud() -> void:
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)
	var top = VBoxContainer.new()
	top.position = Vector2(28,24)
	hud.add_child(top)
	text(top,"FRUIT / MAYHEM",25,MINT)
	stats = text(top,"",14)
	var center = Label.new()
	center.text = "+"
	center.add_theme_font_size_override("font_size",28)
	center.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	center.position -= Vector2(8,16)
	hud.add_child(center)
	var bottom = VBoxContainer.new()
	bottom.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	bottom.position = Vector2(28,-104)
	hud.add_child(bottom)
	var plate = Panel.new()
	plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	plate.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	plate.position = Vector2(14,-118)
	plate.size = Vector2(880,106)
	plate.add_theme_stylebox_override("panel",style(Color(.03,.10,.15,.86),Color(.3,.5,.5,.3)))
	hud.add_child(plate)
	hud.move_child(plate,0)
	tool_label = text(bottom,"",23,AMBER)
	hint = text(bottom,"",14)
	text(bottom,"Q  spawn    TAB  tools    F  grab    T  slow-mo    X  x-ray    ESC  menu",14,Color("b4d1cf"))
	toast_label = Label.new()
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast_label.position += Vector2(-280,32)
	toast_label.custom_minimum_size.x = 560
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.add_theme_color_override("font_color",AMBER)
	root.add_child(toast_label)

func is_open() -> bool: return page != ""

func clear_screen() -> void:
	if is_instance_valid(screen):
		root.remove_child(screen)
		screen.queue_free()
	preview = null
	preview_root = null
	preview_model = null

func open(which: String) -> void:
	clear_screen()
	page = which
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	game.paused = true
	game.apply_time()
	hud.visible = false
	screen = PanelContainer.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.add_theme_stylebox_override("panel",style(Color(.025,.07,.105,.87),Color.TRANSPARENT,0))
	root.add_child(screen)
	var margin = MarginContainer.new()
	for side in ["left","right"]: margin.add_theme_constant_override("margin_"+side,42)
	for side in ["top","bottom"]: margin.add_theme_constant_override("margin_"+side,26)
	screen.add_child(margin)
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation",14)
	margin.add_child(column)
	var header = HBoxContainer.new()
	column.add_child(header)
	var title = text(header,"FRUIT / MAYHEM",24,MINT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text(header,"3D PHYSICS PLAYGROUND  /  V0.1",13,Color("a4b8b9"))
	var body = HBoxContainer.new()
	body.add_theme_constant_override("separation",34)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(body)
	match which:
		"main": main_menu(body)
		"pause": pause_menu(body)
		"spawn": spawn_menu(body)
		"tools": tools_menu(body)
		"maps": map_menu(body)
		"settings": settings_menu(body)
		"credits": credits_menu(body)
		"world": world_menu(body)
		"loading": loading_menu(body)
	if which not in ["main","loading"]: button(column,"←  BACK / RESUME",func(): close())

func close() -> void:
	if not game.started:
		open("main")
		return
	clear_screen()
	page = ""
	hud.visible = true
	game.paused = false
	game.apply_time()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func column(parent: Node, width: float = 330) -> VBoxContainer:
	var box = VBoxContainer.new()
	box.custom_minimum_size.x = width
	box.add_theme_constant_override("separation",9)
	parent.add_child(box)
	return box

func main_menu(body: Node) -> void:
	var left = column(body,370)
	text(left,"LET IT\nGET JUICY.",58)
	text(left,"Ten personalities. One playground.\nPick a fruit. Bend the rules.",18,Color("b2cbcc"))
	button(left,"PLAY  →",func(): game.start_game(false),true)
	button(left,"SANDBOX / MAPS",func(): open("maps"))
	button(left,"CHALLENGE / JUICE DROP",func(): game.start_game(true))
	button(left,"MAP EDITOR / BUILD",func(): game.start_game(false); open("spawn"))
	var row = HBoxContainer.new()
	left.add_child(row)
	button(row,"SETTINGS",func(): open("settings"))
	button(row,"CREDITS",func(): open("credits"))
	button(left,"EXIT",func(): game.get_tree().quit())
	make_preview(body,2)

func pause_menu(body: Node) -> void:
	var left = column(body,380)
	text(left,"TAKE A\nBREATHER.",48)
	button(left,"RESUME  →",func(): close(),true)
	button(left,"WORLD / TIME / WEATHER",func(): open("world"))
	button(left,"SAVE WORLD",func(): game.save_world())
	button(left,"LOAD WORLD",func(): game.load_world())
	button(left,"CHOOSE MAP",func(): open("maps"))
	button(left,"SETTINGS",func(): open("settings"))
	button(left,"MAIN MENU",func(): game.started=false; open("main"))
	make_preview(body,0)

func make_preview(parent: Node, kind: int) -> void:
	var right = column(parent,300)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text(right,"MEET THE LOCALS",15,AMBER)
	var container = SubViewportContainer.new()
	container.stretch = true
	container.custom_minimum_size = Vector2(280,270)
	container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_child(container)
	preview = SubViewport.new()
	preview.size = Vector2i(450,380)
	preview.transparent_bg = true
	preview.own_world_3d = true
	container.add_child(preview)
	preview_root = Node3D.new()
	preview.add_child(preview_root)
	var cam = Camera3D.new()
	cam.position = Vector3(0,.7,3.1)
	preview_root.add_child(cam)
	cam.look_at(Vector3(0,.05,0))
	var light = DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35,-30,0)
	light.light_energy = 1.5
	preview_root.add_child(light)
	var env = WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color("b1d7e2")
	env.environment.ambient_light_energy = .8
	preview_root.add_child(env)
	set_preview(kind)
	text(right,"PROCEDURAL CHARACTERS / REAL PHYSICS",13,Color("a9c5c4"))
	text(right,"CREATIVE CHAOS. ZERO SERIOUSNESS.",18,MINT)

func set_preview(kind: int) -> void:
	if not is_instance_valid(preview_root): return
	if is_instance_valid(preview_model):
		preview_root.remove_child(preview_model)
		preview_model.queue_free()
	preview_model = Art.fruit(kind)
	preview_root.add_child(preview_model)
	for side in [-1,1]:
		var arm = Art.sphere(preview_model,Vector3(side*.78,-.25,0),Vector3(.13,.34,.13),Art.material(Color("303e55")))
		arm.rotation.z = side*.35
		Art.sphere(preview_model,Vector3(side*.88,-.5,0),Vector3.ONE*.16,Art.material(Color("fff1d6")))
		Art.sphere(preview_model,Vector3(side*.3,-.86,.05),Vector3(.11,.3,.11),Art.material(Color("303e55")))
		Art.sphere(preview_model,Vector3(side*.3,-1.12,.13),Vector3(.18,.13,.25),Art.material(Color("26364d")))

func spawn_menu(body: Node) -> void:
	var left = column(body,440)
	text(left,"MAKE SOME CHAOS",32)
	var categories = HBoxContainer.new()
	left.add_child(categories)
	for category in ["FRUIT","PROPS","BUILD"]:
		button(categories,category,func(): spawn_category=category; open("spawn"),spawn_category==category)
	var search = LineEdit.new()
	search.placeholder_text = "Search the catalog..."
	search.custom_minimum_size.y = 40
	left.add_child(search)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(scroll)
	var grid = GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation",8)
	grid.add_theme_constant_override("v_separation",8)
	scroll.add_child(grid)
	var values: Array = Art.NAMES if spawn_category=="FRUIT" else (["Crate","Barrel","Ball","Metal ball","Car"] if spawn_category=="PROPS" else ["Plank","Spring","Crate","Barrel"])
	for index in range(values.size()):
		var value: String = values[index]
		var idx = index
		var b = button(grid,("●  " if spawn_category=="FRUIT" else "◇  ")+value,func():
			if spawn_category=="FRUIT": game.spawn_fruit(idx,game.player.spawn_position())
			else: game.spawn_prop(value,game.player.spawn_position())
			close())
		b.custom_minimum_size = Vector2(205,56)
		if spawn_category=="FRUIT":
			b.add_theme_color_override("font_color",Art.COLORS[idx].lightened(.25))
			b.mouse_entered.connect(func(): set_preview(idx))
	search.text_changed.connect(func(query):
		for b in grid.get_children(): b.visible = query.to_lower() in b.text.to_lower())
	text(left,"Click to spawn where you aim.\nF move · Z rotate held object · Delete remove",14,Color("a9c5c4"))
	make_preview(body,selected_kind)

func tools_menu(body: Node) -> void:
	var left = column(body,440)
	text(left,"POCKET SCIENCE",32)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(scroll)
	var list = column(scroll,420)
	for i in range(game.TOOLS.size()):
		var idx = i
		button(list,"%d  /  %s"%[i+1,game.TOOLS[i]],func(): game.tool=idx; close(),i==game.tool)
	var right = column(body,350)
	text(right,"HOW TO PLAY",26,AMBER)
	text(right,"IMPULSE  ·  click to launch\nRight click for a shockwave\n\nGRAVITY  ·  click to hold\nRight click to throw\n\nFREEZE  ·  toggle suspension\nSIZE  ·  grow / shrink\nBUBBLE  ·  lift / release\nTELEPORT  ·  move to marker\nRight click to place marker\nBALL CANNON  ·  launch a ball\nWAVE  ·  push / pull",19)

func map_menu(body: Node) -> void:
	var left = column(body,500)
	text(left,"PICK YOUR PLAYGROUND",32)
	for i in range(3):
		var idx = i
		button(left,"0%d  /  %s"%[i+1,PlaygroundMaps.TITLES[i]],func(): game.travel_to_map(idx),i==game.map_id)
	text(left,"ARENA  ·  ramps, bounce pads, air lift\nCITY  ·  drive, explore, stack crates\nFACTORY  ·  conveyors, lift, juice silos",18,Color("b2cbcc"))
	text(left,"Each map has a gold Juice Drop target.\nChallenge: launch 5 fruit into the target in 90s.",17,AMBER)
	make_preview(body,6)

func scroll_column(parent: Node, width: float) -> VBoxContainer:
	var scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(scroll)
	return column(scroll,width)

func slider(parent: Node, caption: String, lo: float, hi: float, value: float, callback: Callable, step: float = .05) -> void:
	var title = text(parent,caption+"  /  "+str(snappedf(value,.01)),16)
	var s = HSlider.new()
	s.min_value=lo
	s.max_value=hi
	s.step=step
	s.value=value
	s.custom_minimum_size.y=30
	parent.add_child(s)
	s.value_changed.connect(func(v): title.text=caption+"  /  "+str(snappedf(v,.01)); callback.call(v))

func settings_menu(body: Node) -> void:
	var left = scroll_column(body,400)
	text(left,"TUNE THE EXPERIENCE",30)
	var quality = OptionButton.new()
	for q in ["Very Low","Low","Medium","High"]: quality.add_item(q)
	quality.selected = game.quality
	quality.custom_minimum_size.y = 42
	left.add_child(quality)
	quality.item_selected.connect(func(v): game.quality=v; game.apply_settings(); game.save_settings())
	slider(left,"3D render scale",.5,1,game.render_scale,func(v): game.render_scale=v; game.apply_settings(); game.save_settings())
	slider(left,"Master volume",0,1,game.volume,func(v): game.volume=v; game.apply_settings(); game.save_settings())
	slider(left,"Music",0,1,game.music_volume,func(v): game.music_volume=v; game.apply_settings(); game.save_settings())
	slider(left,"Mouse sensitivity",.001,.006,game.sensitivity,func(v): game.sensitivity=v; game.save_settings(),.0002)
	button(left,"WINDOW / FULLSCREEN",func():
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN))
	var right = scroll_column(body,380)
	text(right,"KEY BINDINGS",25,AMBER)
	text(right,"Select an action, then press a key.\nEsc cancels. Duplicates swap actions.",14)
	for action in game.bindings:
		var name_of_action: String = action
		button(right,action.to_upper()+"  /  "+OS.get_keycode_string(game.bindings[action]),func(): pending_action=name_of_action; game.toast("Press a key for "+name_of_action))

func world_menu(body: Node) -> void:
	var left = column(body,450)
	text(left,"BEND THE RULES",34)
	slider(left,"Gravity",.1,2,game.gravity_factor,func(v): game.gravity_factor=v; game.apply_gravity())
	button(left,"DAY / NIGHT",func(): game.night=not game.night; game.apply_environment())
	for weather in ["Sun","Rain","Snow"]:
		button(left,weather.to_upper(),func(): game.weather=weather; game.apply_environment(),game.weather==weather)
	button(left,"CLEAR PLACED OBJECTS",func(): game.clear_objects(); game.toast("Playground cleared"))
	button(left,"RESET THIS MAP",func(): game.change_map(game.map_id); close())
	var right = column(body,350)
	text(right,"BUILD SOMETHING ODD.",25,AMBER)
	text(right,"Q opens the construction catalog.\nStack planks, barrels and crates.\nF holds a body in front of you.\nZ rotates the held body.\nDelete removes the aimed body.\n\nSave / Load are in the pause menu.\nOnly placed fruit and props are saved.\nStatic map geometry stays intact.",18)

func credits_menu(body: Node) -> void:
	var left = column(body,700)
	text(left,"MADE OF GOOD STUFF.",38)
	text(left,"FRUIT MAYHEM 3D / First playable edition\n\nBuilt with Godot 4.6.3 · GDScript\nOriginal procedural characters, environment, textures and audio.\nNo external asset packs or copyrighted samples.\n\nThis edition includes 10 fruit types, 3 compact maps,\n8 devices, physics props and a Juice Drop challenge.\n\nGodot is distributed under the MIT license.\nSee LICENSES.md and README.md for scope and known limits.",20)

func _input(event: InputEvent) -> void:
	if pending_action!="" and event is InputEventKey and event.pressed:
		if event.keycode!=KEY_ESCAPE:
			game.remap(pending_action,event.physical_keycode)
		pending_action=""
		open("settings")
		get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if is_instance_valid(preview_model): preview_model.rotation.y = sin(Time.get_ticks_msec()*.00035)*.45
	toast_timer -= delta/maxf(Engine.time_scale,.001)
	toast_label.visible = toast_timer>0
	if game.started:
		stats.text = "%s   /   %d FPS   /   %d FRUIT"%[PlaygroundMaps.TITLES[game.map_id],Engine.get_frames_per_second(),get_tree().get_nodes_in_group("fruit").size()]
		if game.challenge:
			stats.text += "   /   JUICE DROP %d/5   %ds"%[game.score,int(game.challenge_time)]
		tool_label.text = "%02d / %s"%[game.tool+1,game.TOOLS[game.tool]]+("   ·   SLOW MO" if game.slow else "")
		var hit = game.player.ray(10)
		if hit and hit.collider is FruitNPC:
			var f = hit.collider
			hint.text = "%s  ·  %s  ·  %.1f kg  /  F grab · E greet"%[Art.NAMES[f.kind],FruitNPC.Mood.keys()[f.mood],f.mass]
		elif hit and hit.collider is PlayProp:
			hint.text = hit.collider.kind+"  /  "+("E drive · F grab" if hit.collider.kind=="Car" else "F grab · Delete remove")
		else: hint.text = "Click to use · Right click alternate · V camera · P photo · F12 screenshot"

func toast(value: String) -> void:
	toast_label.text = value
	toast_timer = 3.5

func loading_menu(body: Node) -> void:
	var box = column(body,700)
	text(box,"PACKING THE PLAYGROUND...",38,MINT)
	text(box,PlaygroundMaps.TITLES[game.map_id],25,AMBER)
	loading_progress = ProgressBar.new()
	loading_progress.custom_minimum_size = Vector2(600,30)
	box.add_child(loading_progress)
	text(box,"TIP / Use T to slow down time and watch the joints react.
Right-click the Impulse glove for an area shockwave.",18)
