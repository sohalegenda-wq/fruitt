class_name Art
extends RefCounted

const NAMES = ["Apple", "Banana", "Watermelon", "Orange", "Lemon", "Pear", "Pineapple", "Kiwi", "Strawberry", "Grape"]
const COLORS = [Color("ee4959"),Color("ffdb51"),Color("66b94b"),Color("ff9c32"),Color("f5e44c"),Color("a3d452"),Color("ecc44f"),Color("977247"),Color("f03d61"),Color("9873e8")]
static var cache: Dictionary = {}

static func material(color: Color, metallic: float = 0.0, roughness: float = 0.6) -> StandardMaterial3D:
	var key = str(color) + str(metallic) + str(roughness)
	if cache.has(key): return cache[key]
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = metallic
	mat.roughness = roughness
	cache[key] = mat
	return mat

static func glow(color: Color) -> StandardMaterial3D:
	var mat = material(color).duplicate()
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 1.4
	return mat

static func mesh(parent: Node3D, resource: Mesh, pos: Vector3, mat: Material, size: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var m = MeshInstance3D.new()
	m.mesh = resource
	m.position = pos
	m.scale = size
	m.material_override = mat
	parent.add_child(m)
	return m

static func sphere(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var s = SphereMesh.new()
	s.radius = 1.0
	s.height = 2.0
	s.radial_segments = 20
	s.rings = 12
	return mesh(parent,s,pos,mat,size)

static func box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var b = BoxMesh.new()
	b.size = size
	return mesh(parent,b,pos,mat)

static func cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, top: float = -1.0) -> MeshInstance3D:
	var c = CylinderMesh.new()
	c.top_radius = radius if top < 0 else top
	c.bottom_radius = radius
	c.height = height
	c.radial_segments = 20
	return mesh(parent,c,pos,mat)

static func label(parent: Node3D, value: String, pos: Vector3, size: int = 64, color: Color = Color.WHITE) -> Label3D:
	var l = Label3D.new()
	l.text = value
	l.position = pos
	l.font_size = size
	l.pixel_size = 0.012
	l.modulate = color
	l.outline_size = 3
	parent.add_child(l)
	return l

static func rind(kind: int) -> StandardMaterial3D:
	var key = "rind%d" % kind
	if cache.has(key): return cache[key]
	var mat = material(COLORS[kind]).duplicate()
	mat.albedo_texture = load("res://assets/textures/rind.png")
	mat.normal_enabled = true
	mat.normal_texture = load("res://assets/textures/rind_normal.png")
	mat.normal_scale = 0.45 if kind != 7 else 1.4
	mat.roughness = .42 if kind in [0,9] else .72
	if kind == 2 or kind == 6:
		mat.albedo_color = Color.WHITE
		mat.albedo_texture = load("res://assets/textures/melon.png" if kind == 2 else "res://assets/textures/pineapple.png")
	cache[key] = mat
	return mat

static func fruit_surface(kind: int) -> ArrayMesh:
	var key = "surface%d" % kind
	if cache.has(key): return cache[key]
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rings = 28
	var segments = 40
	var vertices: Array[Vector3] = []
	var uvs: Array[Vector2] = []
	for j in range(rings+1):
		var v = float(j)/rings
		var phi = v * PI
		for i in range(segments+1):
			var u = float(i)/segments
			var theta = u * TAU
			var r = sin(phi)
			var yy = cos(phi)
			var p = Vector3(cos(theta)*r,yy,sin(theta)*r)
			match kind:
				0:
					var lobes = 1.0+.045*cos(theta*5)*pow(abs(yy),3)
					p = Vector3(p.x*.70*lobes, yy*.68-.12*exp(-r*r*24)*sign(yy),p.z*.65*lobes)
				1:
					var tube = .25*sin(phi)
					p = Vector3(.70*sin(v*PI)-.25+tube*cos(theta),1.18-v*2.25,tube*sin(theta))
				2: p *= Vector3(1.05,.88,.80)
				3: p *= Vector3(.66,.68,.65)
				4: p *= Vector3(.56,.84,.55); p.y += .10*pow(abs(yy),9)*sign(yy)
				5: p *= Vector3(.62*(1-.4*yy),.90,.59*(1-.4*yy))
				6: p *= Vector3(.59,.87,.59)
				7: p *= Vector3(.56,.75,.53)
				8:
					p *= Vector3(.72*(.75+.35*yy),.83,.66*(.75+.35*yy))
			vertices.append(p)
			uvs.append(Vector2(u,v))
	for j in range(rings):
		for i in range(segments):
			var a = j*(segments+1)+i
			for idx in [a,a+1,a+segments+1,a+1,a+segments+2,a+segments+1]:
				st.set_uv(uvs[idx])
				st.add_vertex(vertices[idx])
	st.generate_normals()
	st.generate_tangents()
	var result = st.commit()
	cache[key] = result
	return result

static func leaf(parent: Node3D, pos: Vector3, angle: float, length: float = .50) -> void:
	var l = sphere(parent,pos,Vector3(.14,length,.045),material(Color("459757")))
	l.rotation.z = angle

static func fruit(kind: int) -> Node3D:
	var root = Node3D.new()
	if kind == 9:
		for row in range(4):
			for i in range(4-row):
				var a = i*TAU/max(1,4-row)+row*.8
				sphere(root,Vector3(cos(a)*(.37-row*.07),.6-row*.39,sin(a)*(.37-row*.07)),Vector3.ONE*.34,rind(kind))
	else:
		mesh(root,fruit_surface(kind),Vector3.ZERO,rind(kind))
	var top = [0.63,1.13,.84,.67,.86,.89,.87,.74,.81,.78][kind]
	if kind not in [1,4,7]:
		var stem = cylinder(root,Vector3(.025,top+.13,0),.055,.28,material(Color("66523b")))
		stem.rotation.z = -.24
		leaf(root,Vector3(.19,top+.13,0),-.95,.30)
	if kind == 6 or kind == 8:
		for i in range(7):
			var a = i*TAU/7
			var crown = Node3D.new()
			root.add_child(crown)
			crown.position.y = top
			crown.rotation.y = a
			leaf(crown,Vector3(.15,.25 if kind==6 else .02,0),-.6,.55 if kind==6 else .30)
	if kind == 8:
		for i in range(42):
			var y = -.6+float(i%7)*.19
			var a = (i*2.399)
			var r = sqrt(max(.01,1-pow(y/.83,2)))*.68*(.75+.35*y/.83)
			sphere(root,Vector3(cos(a)*r,y,sin(a)*r*.93),Vector3(.027,.045,.025),material(Color("ffe9a4")))
	if kind == 7:
		for i in range(45):
			var a = i*2.399
			var y = -.65+(i%9)*.15
			var r = sqrt(max(.01,1-pow(y/.75,2)))*.55
			var hair = cylinder(root,Vector3(cos(a)*r,y,sin(a)*r),.009,.10,material(Color("c1a075")))
			hair.rotation.z = a
	# Forward is +Z. Raised glossy eyes and cheek dots.
	var depth = [.61,.27,.75,.61,.52,.53,.55,.51,.56,.59][kind]
	for side in [-1,1]:
		sphere(root,Vector3(side*.215,.13,depth),Vector3(.155,.18,.085),material(Color("fff5dc")))
		sphere(root,Vector3(side*.215,.12,depth+.074),Vector3(.078,.103,.035),material(Color("172332")))
		sphere(root,Vector3(side*.215-.022,.156,depth+.106),Vector3.ONE*.024,material(Color.WHITE))
		sphere(root,Vector3(side*.35,-.09,depth-.01),Vector3(.09,.045,.025),material(Color("f48489")))
	# Curved smile, built from a continuous smooth tube.
	for i in range(11):
		var x = -.15+i*.03
		sphere(root,Vector3(x,-.20+pow(x/.15,2)*.08,depth+.03),Vector3(.024,.024,.025),material(Color("432839")))
	return root

static func interior() -> Node3D:
	var n = Node3D.new()
	sphere(n,Vector3.ZERO,Vector3.ONE*.25,glow(Color("6df4e0")))
	for i in range(6):
		var a = i*TAU/6
		var p = Vector3(cos(a)*.36,sin(a)*.36,0)
		sphere(n,p,Vector3(.13,.18,.15),glow(Color("f69ac7") if i%2 else Color("ffcf71")))
		var fiber = cylinder(n,p*.5,.017,p.length(),glow(Color("8bf2bc")))
		fiber.rotation.z = a-PI/2
	var crystal = cylinder(n,Vector3(0,.48,0),.13,.28,glow(Color("c5a2ff")),0)
	crystal.rotation.z = .25
	for i in range(5):
		sphere(n,Vector3(cos(i*TAU/5)*.17,-.42,sin(i*TAU/5)*.17),Vector3(.05,.09,.05),material(Color("744c98")))
	return n
