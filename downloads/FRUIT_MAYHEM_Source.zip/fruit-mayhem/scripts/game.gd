extends Node3D

const TOOLS = ["Impulse glove","Gravity grip","Freeze ray","Size ray","Bubble wand","Teleporter","Ball cannon","Shockwave / Magnet"]
var bindings = {"forward":KEY_W,"back":KEY_S,"left":KEY_A,"right":KEY_D,"sprint":KEY_SHIFT,"jump":KEY_SPACE,"crouch":KEY_CTRL,"interact":KEY_E,"grab":KEY_F,"drop":KEY_G,"spawn":KEY_Q,"tools":KEY_TAB,"reset_tool":KEY_R,"slow":KEY_T,"xray":KEY_X,"view":KEY_V,"photo":KEY_P,"rotate":KEY_Z,"delete":KEY_DELETE,"screenshot":KEY_F12,"pause":KEY_ESCAPE}
var player: SandboxPlayer
var ui: MayhemUI
var world: PlaygroundMaps
var objects: Node3D
var environment: WorldEnvironment
var sun: DirectionalLight3D
var music: AudioStreamPlayer
var audio_pool: Array[AudioStreamPlayer3D] = []
var effect_pool: Array[CPUParticles3D] = []
var weather_particles: CPUParticles3D
var started = false
var paused = true
var slow = false
var xray = false
var night = false
var weather = "Sun"
var quality = 1
var render_scale = 1.0
var volume = .7
var music_volume = .35
var sensitivity = .0025
var gravity_factor = 1.0
var tool = 0
var map_id = 0
var npc_limit = 24
var body_limit = 80
var teleport_marker = Vector3(0,3,0)
var challenge = false
var challenge_time = 90.0
var score = 0
var impact_count = 0
var testing = false
var capturing = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	testing = "--smoke-test" in OS.get_cmdline_user_args()
	load_settings()
	install_inputs()
	objects = Node3D.new()
	objects.name = "PlacedObjects"
	objects.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(objects)
	make_environment()
	make_pools()
	player = SandboxPlayer.new()
	player.game = self
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(player)
	player.position = Vector3(0,1,14)
	ui = MayhemUI.new()
	ui.game = self
	ui.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui)
	change_map(0)
	apply_settings()
	ui.open("main")
	if "--capture" in OS.get_cmdline_user_args(): call_deferred("capture_gallery")
	elif testing: call_deferred("smoke_test")
	elif "--tour" in OS.get_cmdline_user_args():
		start_game(false)
		player.position = Vector3(15,6,22)
		player.rotation.y = .55
		player.pitch = -.22
		player.pivot.rotation.x = -.22
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func install_inputs() -> void:
	for action in bindings:
		if not InputMap.has_action(action): InputMap.add_action(action)
		InputMap.action_erase_events(action)
		var event = InputEventKey.new()
		event.physical_keycode = int(bindings[action])
		InputMap.action_add_event(action,event)
	for pair in [["shoot",MOUSE_BUTTON_LEFT],["alt",MOUSE_BUTTON_RIGHT]]:
		if not InputMap.has_action(pair[0]): InputMap.add_action(pair[0])
		var e = InputEventMouseButton.new()
		e.button_index = pair[1]
		InputMap.action_add_event(pair[0],e)

func remap(action: String, key: int) -> void:
	var old = bindings[action]
	for other in bindings:
		if other!=action and bindings[other]==key: bindings[other]=old
	bindings[action]=key
	install_inputs()
	save_settings()

func make_environment() -> void:
	environment = WorldEnvironment.new()
	var e = Environment.new()
	e.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	var mat = ProceduralSkyMaterial.new()
	mat.sky_top_color = Color("508caa")
	mat.sky_horizon_color = Color("d1e3dc")
	mat.ground_horizon_color = Color("cbd5ca")
	mat.ground_bottom_color = Color("627f85")
	sky.sky_material = mat
	e.sky = sky
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color("b6cbd4")
	e.ambient_light_energy = .38
	e.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	e.tonemap_exposure = .85
	e.fog_enabled = true
	e.fog_light_color = Color("a8c6c9")
	e.fog_density = .0018
	environment.environment = e
	add_child(environment)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48,-32,0)
	sun.light_color = Color("ffe2b2")
	sun.light_energy = .85
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 65
	add_child(sun)

func make_pools() -> void:
	for i in range(16):
		var p = AudioStreamPlayer3D.new()
		p.max_distance = 50
		p.unit_size = 7
		add_child(p)
		audio_pool.append(p)
	for i in range(10):
		var fx = CPUParticles3D.new()
		fx.process_mode = Node.PROCESS_MODE_PAUSABLE
		fx.emitting = false
		fx.one_shot = true
		fx.amount = 22
		fx.lifetime = .7
		fx.explosiveness = 1.0
		fx.direction = Vector3.UP
		fx.spread = 160
		fx.initial_velocity_min = 2
		fx.initial_velocity_max = 5
		fx.gravity = Vector3(0,-10,0)
		fx.scale_amount_min = .06
		fx.scale_amount_max = .16
		var drop = SphereMesh.new()
		drop.radius = 1
		drop.height = 2
		drop.radial_segments = 8
		drop.rings = 4
		fx.mesh = drop
		add_child(fx)
		effect_pool.append(fx)
	weather_particles = CPUParticles3D.new()
	weather_particles.process_mode = Node.PROCESS_MODE_PAUSABLE
	weather_particles.emitting = false
	weather_particles.amount = 180
	weather_particles.lifetime = 3
	weather_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	weather_particles.emission_box_extents = Vector3(15,1,15)
	weather_particles.direction = Vector3.DOWN
	weather_particles.spread = 8
	weather_particles.initial_velocity_min = 7
	weather_particles.initial_velocity_max = 10
	weather_particles.gravity = Vector3(0,-3,0)
	weather_particles.scale_amount_min = .025
	weather_particles.scale_amount_max = .04
	var snow = SphereMesh.new()
	snow.radius = 1
	snow.height = 2
	snow.radial_segments = 6
	snow.rings = 3
	weather_particles.mesh = snow
	add_child(weather_particles)
	music = AudioStreamPlayer.new()
	music.stream = load("res://assets/audio/music.wav")
	add_child(music)
	music.stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	music.play()

func sound(sound_name: String, pos: Vector3, pitch_value: float = 1, gain: float = .8) -> void:
	if volume<=.001 or testing: return
	for p in audio_pool:
		if not p.playing:
			p.stream = load("res://assets/audio/"+sound_name+".wav")
			p.global_position = pos
			p.pitch_scale = pitch_value
			p.volume_db = linear_to_db(maxf(volume*gain,.001))
			p.play()
			return

func burst(pos: Vector3, color: Color) -> void:
	impact_count += 1
	if quality==0: return
	for fx in effect_pool:
		if not fx.emitting:
			fx.global_position = pos
			fx.color = color
			fx.mesh.material = Art.material(color)
			fx.amount = 12 if quality==1 else 24
			fx.restart()
			fx.emitting = true
			return

func spawn_fruit(kind: int, pos: Vector3) -> FruitNPC:
	if get_tree().get_nodes_in_group("fruit").size()>=npc_limit or get_tree().get_nodes_in_group("saveable").size()>=body_limit:
		toast("Body limit reached. Remove some objects first.")
		return null
	var fruit = FruitNPC.new()
	fruit.kind = clampi(kind,0,9)
	fruit.game = self
	fruit.position = pos
	objects.add_child(fruit)
	fruit.gravity_scale = gravity_factor
	fruit.set_xray(xray)
	return fruit

func spawn_prop(kind: String, pos: Vector3) -> PlayProp:
	if get_tree().get_nodes_in_group("saveable").size()>=body_limit:
		toast("Body limit reached.")
		return null
	var prop = PlayProp.new()
	prop.kind = kind
	prop.game = self
	prop.position = pos
	objects.add_child(prop)
	prop.gravity_scale = gravity_factor
	return prop

func clear_objects() -> void:
	player.held = null
	if is_instance_valid(player.vehicle):
		player.vehicle.driven = false
		player.vehicle = null
	for child in objects.get_children():
		objects.remove_child(child)
		child.queue_free()

func change_map(index: int, populate: bool = true) -> void:
	clear_objects()
	if is_instance_valid(world):
		remove_child(world)
		world.queue_free()
	map_id = clampi(index,0,2)
	world = PlaygroundMaps.new()
	world.game = self
	world.map_id = map_id
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(world)
	if not populate: clear_objects()
	else:
		for i in range(10):
			spawn_fruit(i,Vector3(-6+(i%5)*3,2.2,7-(i/5)*6))
	player.global_position = Vector3(0,1,15)
	player.velocity = Vector3.ZERO
	player.rotation.y = 0
	gravity_factor = 1
	apply_gravity()
	apply_settings()

func start_game(challenge_mode: bool) -> void:
	started = true
	challenge = challenge_mode
	challenge_time = 90
	score = 0
	for fruit in get_tree().get_nodes_in_group("fruit"): fruit.scored=false
	if challenge_mode and get_tree().get_nodes_in_group("fruit").size()<5:
		for i in range(5): spawn_fruit(i,Vector3(-5+i*2,2,5))
	ui.close()
	toast("JUICE DROP: launch 5 fruit into the gold target in 90 seconds!" if challenge else "Welcome! Q spawn · Tab tools · Click launch · T slow motion")

func apply_time() -> void:
	get_tree().paused = paused
	Engine.time_scale = .22 if slow else 1.0
	AudioServer.playback_speed_scale = .75 if slow else 1.0

func _input(event: InputEvent) -> void:
	if not is_instance_valid(ui) or ui.pending_action!="": return
	if event.is_action_pressed("pause"):
		if ui.is_open(): ui.close()
		else: ui.open("pause")
		get_viewport().set_input_as_handled()
		return
	if ui.is_open(): return
	if event.is_action_pressed("spawn"): ui.open("spawn")
	if event.is_action_pressed("tools"): ui.open("tools")
	if event.is_action_pressed("slow"):
		slow = not slow
		apply_time()
	if event.is_action_pressed("xray"):
		xray = not xray
		for f in get_tree().get_nodes_in_group("fruit"): f.set_xray(xray)
		toast("X-RAY / Juice core · Jelly chambers · Seed reactor" if xray else "X-ray off")
	if event is InputEventKey and event.pressed and event.physical_keycode>=KEY_1 and event.physical_keycode<=KEY_8:
		tool = event.physical_keycode-KEY_1

func _process(delta: float) -> void:
	if is_instance_valid(player): weather_particles.position = player.position+Vector3(0,12,0)
	if paused or not challenge: return
	challenge_time -= delta
	for fruit in get_tree().get_nodes_in_group("fruit"):
		var d = fruit.position-world.target_position
		if not fruit.scored and abs(d.x)<3.5 and abs(d.z)<2.5 and d.y<3 and fruit.mood==FruitNPC.Mood.RAGDOLL:
			fruit.scored = true
			score += 1
			burst(fruit.position,Color("ffe18b"))
			toast("JUICE DROP! %d / 5"%score)
	if score>=5 or challenge_time<=0:
		challenge = false
		toast("CHALLENGE COMPLETE / 5 JUICY POINTS!" if score>=5 else "TIME UP / %d of 5. Try again from the menu."%score)

func shockwave(pos: Vector3, polarity: int = 1) -> void:
	for body in get_tree().get_nodes_in_group("saveable"):
		var d = body.global_position-pos
		var length = d.length()
		if length<11 and length>.1:
			var impulse = (d.normalized()*polarity+Vector3.UP*.5)*body.mass*(11-length)*2
			if body is FruitNPC: body.knock(impulse)
			elif not body.freeze: body.apply_central_impulse(impulse)
	burst(pos,Color("88e6d1"))
	sound("pulse",pos)

func apply_gravity() -> void:
	for body in get_tree().get_nodes_in_group("saveable"):
		body.gravity_scale = gravity_factor
		if body is FruitNPC:
			for part in body.limbs: part.gravity_scale = gravity_factor

func apply_environment() -> void:
	sun.light_energy = .22 if night else .85
	sun.light_color = Color("95bcf6") if night else Color("ffe2b2")
	environment.environment.ambient_light_energy = .3 if night else .38
	var sky_mat = environment.environment.sky.sky_material
	sky_mat.sky_top_color = Color("142c4e") if night else Color("508caa")
	sky_mat.sky_horizon_color = Color("527183") if night else Color("d1e3dc")
	weather_particles.emitting = weather!="Sun" and quality>0
	weather_particles.color = Color("f7f7ee") if weather=="Snow" else Color("9cc9df")
	weather_particles.initial_velocity_min = 2 if weather=="Snow" else 9
	weather_particles.initial_velocity_max = 3 if weather=="Snow" else 12
	weather_particles.gravity.y = -.5 if weather=="Snow" else -3
	weather_particles.mesh.material = Art.material(weather_particles.color)

func apply_settings() -> void:
	if not is_instance_valid(sun): return
	sun.shadow_enabled = quality>=1
	sun.directional_shadow_max_distance = [0,35,55,75][quality]
	RenderingServer.directional_shadow_atlas_set_size([512,1024,2048,2048][quality],true)
	get_viewport().scaling_3d_scale = render_scale
	environment.environment.fog_enabled = quality>=2
	music.volume_db = linear_to_db(maxf(volume*music_volume,.0001))
	apply_environment()

func save_settings() -> void:
	var config = ConfigFile.new()
	for name_of_value in ["quality","render_scale","volume","music_volume","sensitivity"]: config.set_value("settings",name_of_value,get(name_of_value))
	for action in bindings: config.set_value("keys",action,bindings[action])
	config.save("user://settings.cfg")

func load_settings() -> void:
	var config = ConfigFile.new()
	if config.load("user://settings.cfg")!=OK: return
	quality = clampi(int(config.get_value("settings","quality",1)),0,3)
	render_scale = clampf(float(config.get_value("settings","render_scale",1.0)),.5,1)
	volume = clampf(float(config.get_value("settings","volume",.7)),0,1)
	music_volume = clampf(float(config.get_value("settings","music_volume",.35)),0,1)
	sensitivity = clampf(float(config.get_value("settings","sensitivity",.0025)),.001,.006)
	for action in bindings: bindings[action] = int(config.get_value("keys",action,bindings[action]))

func save_world(path: String = "user://world.json") -> bool:
	var items: Array = []
	for body in objects.get_children(): items.append(body.snapshot())
	var data = {"version":1,"map":map_id,"items":items,"gravity":gravity_factor,"weather":weather,"night":night}
	var f = FileAccess.open(path,FileAccess.WRITE)
	if not f: toast("Could not save world"); return false
	f.store_string(JSON.stringify(data,"\t"))
	f.close()
	toast("World saved / "+path)
	return true

func load_world(path: String = "user://world.json") -> bool:
	if not FileAccess.file_exists(path): toast("No saved world yet"); return false
	var data = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not data is Dictionary or data.get("version")!=1 or not data.get("items") is Array:
		toast("Save format is invalid"); return false
	var items: Array = data.items
	if items.size()>body_limit: toast("Save exceeds the body limit"); return false
	for item in items:
		if not item is Dictionary or not item.get("pos") is Array or item.pos.size()!=3 or item.get("type","") not in ["fruit","prop"]:
			toast("Invalid item in save"); return false
		for component in item.pos:
			if not (component is float or component is int) or not is_finite(component) or abs(component)>500:
				toast("Invalid position in save"); return false
	change_map(clampi(int(data.get("map",0)),0,2),false)
	for item in items:
		var p = Vector3(float(item.pos[0]),float(item.pos[1]),float(item.pos[2]))
		if item.type=="fruit":
			var f = spawn_fruit(clampi(int(item.get("kind",0)),0,9),p)
			if f:
				f.resize(clampf(float(item.get("size",1)),.6,1.65))
				f.set_frozen(bool(item.get("frozen",false)))
		else:
			var kind_of_prop: String = str(item.get("kind","Crate"))
			if kind_of_prop not in ["Ball","Metal ball","Crate","Car","Barrel","Plank","Spring"]: kind_of_prop="Crate"
			var prop = spawn_prop(kind_of_prop,p)
			if prop:
				prop.rotation.y = float(item.get("yaw",0))
				prop.freeze = bool(item.get("frozen",false))
	gravity_factor = clampf(float(data.get("gravity",1)),.1,2)
	weather = str(data.get("weather","Sun"))
	night = bool(data.get("night",false))
	apply_gravity()
	apply_environment()
	challenge = false
	toast("World loaded")
	return true

func screenshot() -> void:
	if DisplayServer.get_name()=="headless": toast("Screenshot needs a graphics display"); return
	await RenderingServer.frame_post_draw
	var path = "user://photo_%d.png"%Time.get_unix_time_from_system()
	get_viewport().get_texture().get_image().save_png(path)
	toast("Saved photo / "+ProjectSettings.globalize_path(path))

func toast(value: String) -> void:
	if is_instance_valid(ui): ui.toast(value)

func smoke_test() -> void:
	print("TEST: start")
	start_game(false)
	await get_tree().create_timer(.2).timeout
	assert(get_tree().get_nodes_in_group("fruit").size()==10)
	for f in get_tree().get_nodes_in_group("fruit"):
		assert(f.skin.get_child_count()>10)
		assert(f.limbs.size()==4)
		f.knock(Vector3(3,8,0))
		f.set_xray(true)
	await get_tree().create_timer(1).timeout
	for f in get_tree().get_nodes_in_group("fruit"):
		assert(f.mood==FruitNPC.Mood.RAGDOLL)
		assert(f.position.is_finite())
		f.recover()
		f.set_frozen(true)
		assert(f.freeze)
		f.set_frozen(false)
	print("TEST: fruit models, joints, ragdoll, recovery, xray, freeze OK")
	var count = objects.get_child_count()
	assert(save_world("user://test_world.json"))
	assert(load_world("user://test_world.json"))
	assert(objects.get_child_count()==count)
	print("TEST: save/load round-trip OK")
	var walker = get_tree().get_nodes_in_group("fruit")[0]
	walker.position = Vector3(-18,1.8,18)
	walker.think_timer = 8
	walker.emotion_time = 0
	walker.mood = FruitNPC.Mood.WANDER
	walker.target = Vector3(-10,0,18)
	var walk_start = walker.position
	await get_tree().create_timer(1.5).timeout
	assert(Vector2(walker.position.x-walk_start.x,walker.position.z-walk_start.z).length()>.25)
	print("TEST: NPC locomotion over friction OK")
	# Exercise the real camera ray and each device against a stationary target.
	clear_objects()
	player.position = Vector3(0,0,7)
	player.rotation = Vector3.ZERO
	player.pivot.rotation = Vector3.ZERO
	var subject = spawn_fruit(0,Vector3(0,1.6,1))
	subject.set_frozen(true)
	await get_tree().physics_frame
	assert(player.ray(10).get("collider")==subject)
	tool=2
	player.use_tool(false)
	assert(not subject.frozen)
	tool=3
	player.use_tool(false)
	assert(subject.size_factor>1.5)
	player.use_tool(true)
	assert(subject.size_factor<.8)
	tool=4
	player.use_tool(false)
	assert(subject.bubble_timer>0)
	tool=5
	teleport_marker=Vector3(4,3,0)
	player.use_tool(false)
	assert(subject.position.distance_to(teleport_marker)<.1)
	tool=6
	var before=objects.get_child_count()
	player.use_tool(false)
	assert(objects.get_child_count()==before+1)
	tool=0
	player.use_tool(true)
	assert(impact_count>0)
	# Movement and jump use the same input actions as keyboard events.
	player.position=Vector3(0,1,15)
	player.velocity=Vector3.ZERO
	await get_tree().create_timer(.6).timeout
	var original=player.position
	Input.action_press("forward")
	await get_tree().create_timer(.35).timeout
	Input.action_release("forward")
	assert(player.position.z<original.z-.5)
	Input.action_press("jump")
	await get_tree().physics_frame
	Input.action_release("jump")
	await get_tree().physics_frame
	assert(player.velocity.y>0)
	print("TEST: ray, freeze/size/bubble/teleport/cannon/wave, movement/jump OK")
	for i in range(3):
		change_map(i)
		await get_tree().create_timer(.2).timeout
		assert(world.get_child_count()>40)
		assert(objects.get_child_count()>10)
		print("TEST: map ",i," OK")
	for p in ["Plank","Spring","Metal ball","Car"]: assert(spawn_prop(p,Vector3(0,3,0))!=null)
	shockwave(Vector3(0,2,0))
	for i in range(4): quality=i; apply_settings()
	for w in ["Rain","Snow","Sun"]: weather=w; apply_environment()
	for name_of_page in ["pause","spawn","tools","maps","settings","credits","world"]:
		ui.open(name_of_page)
		assert(ui.is_open())
		ui.close()
		await get_tree().process_frame
	print("TEST: UI pages, props, settings, weather OK")
	# Challenge scoring is verified against real target coordinates and ragdoll state.
	start_game(true)
	var fruit_list = get_tree().get_nodes_in_group("fruit")
	for i in range(5):
		fruit_list[i].position = world.target_position+Vector3(i*.15,1.5,0)
		fruit_list[i].knock(Vector3.ZERO)
	_process(.001)
	assert(score>=5)
	assert(not challenge)
	print("TEST: challenge win condition OK")
	get_tree().paused = false
	print("TEST: PASS")
	music.stop()
	music.stream = null
	await get_tree().process_frame
	get_tree().quit(0)

func capture_gallery() -> void:
	capturing = true
	start_game(false)
	player.photo = true
	player.collision_mask = 0
	for child in objects.get_children():
		if child is FruitNPC: child.set_frozen(true)
	player.position = Vector3(9,4.8,17)
	player.rotation.y = .35
	player.pivot.rotation.x = -.21
	await get_tree().create_timer(2).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/workspace/work/arena.png")
	# A deliberately composed close-up of the ten characters.
	clear_objects()
	for i in range(10):
		var f = spawn_fruit(i,Vector3(-5.5+(i%5)*2.7,1.5+(i/5)*.4,-(i/5)*3.0))
		f.set_frozen(true)
	player.position = Vector3(.1,3.2,9)
	player.rotation.y = 0
	player.pivot.rotation.x = -.12
	player.tool_model.visible=false
	await get_tree().create_timer(1).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/workspace/work/characters.png")
	ui.open("main")
	await get_tree().create_timer(1,true).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/workspace/work/main-menu.png")
	ui.close()
	for i in [1,2]:
		change_map(i)
		player.position = Vector3(22,9,23)
		player.rotation.y = .65
		player.pivot.rotation.x = -.28
		await get_tree().create_timer(1).timeout
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/workspace/work/map-%d.png"%i)
	get_tree().quit()

func _exit_tree() -> void:
	Engine.time_scale = 1
	if is_instance_valid(music):
		music.stop()
		music.stream = null
	Art.cache.clear()

func travel_to_map(index: int) -> void:
	map_id = index
	ui.open("loading")
	ui.loading_progress.value = 10
	await get_tree().process_frame
	ui.loading_progress.value = 35
	await get_tree().process_frame
	change_map(index)
	ui.loading_progress.value = 100
	await get_tree().create_timer(.25,true).timeout
	start_game(false)
