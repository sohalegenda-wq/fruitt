class_name PlaygroundMaps
extends Node3D

var game: Node3D
var map_id = 0
var movers: Array[Node3D] = []
var fans: Array[Node3D] = []
var bounce_zones: Array[Vector3] = []
var wind_zones: Array[Vector3] = []
var belt_zones: Array[Vector3] = []
var clock = 0.0
var target_position = Vector3(0,0,-12)
var target_radius = 3.3
const TITLES = ["FRUIT ARENA", "FRUIT CITY", "JUICE FACTORY"]

func _ready() -> void:
	build()

func block(pos: Vector3, size: Vector3, color: Color, rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var b = StaticBody3D.new()
	b.position = pos
	b.rotation = rot
	add_child(b)
	Art.box(b,Vector3.ZERO,size,Art.material(color))
	var c = CollisionShape3D.new()
	var s = BoxShape3D.new()
	s.size = size
	c.shape = s
	b.add_child(c)
	return b

func trim(pos: Vector3, size: Vector3, color: Color) -> void:
	Art.box(self,pos,size,Art.material(color))

func tree(pos: Vector3, color: Color = Color("6fa779")) -> void:
	Art.cylinder(self,pos+Vector3(0,1.1,0),.20,2.2,Art.material(Color("8c7050")),.14)
	for i in range(3):
		Art.sphere(self,pos+Vector3(sin(i*2.1)*.65,2.6+i*.42,cos(i*2.1)*.5),Vector3(1.1,1.2,1),Art.material(color.lightened(i*.04)))
	block(pos+Vector3(0,.18,0),Vector3(2.2,.36,2.2),Color("e4d5b9"))

func lamp(pos: Vector3) -> void:
	Art.cylinder(self,pos+Vector3(0,2,0),.065,4,Art.material(Color("354f61"),.55))
	Art.box(self,pos+Vector3(0,4,0),Vector3(.7,.12,.7),Art.material(Color("354f61"),.5))
	Art.sphere(self,pos+Vector3(0,3.85,0),Vector3(.2,.15,.2),Art.glow(Color("ffe8ae")))

func bench(pos: Vector3, yaw: float = 0) -> void:
	var root = Node3D.new()
	add_child(root)
	root.position = pos
	root.rotation.y = yaw
	for i in range(3): Art.box(root,Vector3(0,.6,-.22+i*.22),Vector3(2.3,.12,.17),Art.material(Color("ba8a61")))
	for x in [-.9,.9]:
		Art.box(root,Vector3(x,.3,0),Vector3(.12,.6,.6),Art.material(Color("344c5b"),.7))
	Art.box(root,Vector3(0,1.1,-.32),Vector3(2.3,.4,.1),Art.material(Color("c49870")))

func trampoline(pos: Vector3) -> void:
	block(pos+Vector3(0,.30,0),Vector3(3,.6,3),Color("35475a"))
	trim(pos+Vector3(0,.63,0),Vector3(2.8,.08,2.8),Color("63dbc2"))
	bounce_zones.append(pos+Vector3(0,1.5,0))
	Art.label(self,"BOUNCE",pos+Vector3(0,.7,0),26).rotation.x = -PI/2

func fan(pos: Vector3) -> void:
	block(pos+Vector3(0,.2,0),Vector3(2.6,.4,2.6),Color("34495a"))
	Art.cylinder(self,pos+Vector3(0,.5,0),1.1,.25,Art.material(Color("94aeb7"),.7))
	var rotor = Node3D.new()
	add_child(rotor)
	rotor.position = pos+Vector3(0,.7,0)
	for i in range(4):
		var blade = Art.box(rotor,Vector3.ZERO,Vector3(1.8,.06,.26),Art.material(Color("f5bf63"),.4))
		blade.rotation.y = i*PI/2
	fans.append(rotor)
	wind_zones.append(pos)
	Art.label(self,"AIR LIFT",pos+Vector3(0,1.3,-1.4),28)

func goal() -> void:
	var p = target_position
	block(p+Vector3(0,.07,0),Vector3(7,.14,5),Color("e6b455"))
	for x in [-3.5,3.5]: block(p+Vector3(x,.65,0),Vector3(.18,1.3,5),Color("2e6b74"))
	block(p+Vector3(0,.65,-2.5),Vector3(7,1.3,.18),Color("2e6b74"))
	Art.label(self,"JUICE DROP / 01",p+Vector3(0,3,-2.5),50,Color("ffdf93"))
	Art.label(self,"LAUNCH FRUIT INTO THE GOLD ZONE",p+Vector3(0,2.3,-2.5),20)

func build() -> void:
	var base = [Color("657c8d"),Color("a3b6a2"),Color("667f85")][map_id]
	block(Vector3(0,-.5,0),Vector3(58,1,58),base)
	for edge in [-1,1]:
		block(Vector3(edge*29,1.1,0),Vector3(.6,2.2,58),Color("41596a"))
		block(Vector3(0,1.1,edge*29),Vector3(58,2.2,.6),Color("41596a"))
	match map_id:
		0: arena()
		1: city()
		2: factory()
	goal()
	for i in range(6):
		lamp(Vector3(-24+i*9,0,23))
		bench(Vector3(-23+i*9,0,25),PI)
	# Distant stylized mountain ring gives a silhouette without expensive geometry.
	for i in range(18):
		var a = float(i)*TAU/18
		var p = Vector3(cos(a)*75,-8,sin(a)*75)
		Art.sphere(self,p,Vector3(randf_range(10,20),randf_range(15,30),12),Art.material(Color("728f9c").darkened(randf()*.15)))

func arena() -> void:
	for x in range(-4,5):
		for z in range(-4,5):
			trim(Vector3(x*5,.012,z*5),Vector3(4.96,.018,4.96),Color("78929e") if (x+z)%2 else Color("819aa5"))
	for x in [-27,27]:
		for i in range(3): block(Vector3(x, .4+i*.45,-8+i*.8),Vector3(2,.8+i*.8,20-i*2),Color("c5b8a3"))
	block(Vector3(-10,.9,-4),Vector3(5,.35,9),Color("ebb768"),Vector3(.25,0,0))
	block(Vector3(-10,2,-9),Vector3(5,.4,2),Color("ecb970"))
	trampoline(Vector3(10,0,-3))
	fan(Vector3(15,0,7))
	for x in [-21,21]:
		for z in [-20,17]: tree(Vector3(x,0,z))
	var arch = block(Vector3(0,6,21),Vector3(14,.7,.7),Color("283f55"))
	Art.label(arch,"FRUIT / MAYHEM",Vector3(0,-.02,.45),58,Color("ffe2a4"))
	for x in [-7,7]: block(Vector3(x,3,21),Vector3(.55,6,.55),Color("2b4359"))
	for i in range(3): game.spawn_prop("Crate",Vector3(-8+i*1.2,1.3,4))
	game.spawn_prop("Car",Vector3(13,1,14))
	game.spawn_prop("Ball",Vector3(-3,1,8))
	game.spawn_prop("Barrel",Vector3(6,1,4))
	moving_platform(Vector3(-16,2,6))
	Art.label(self,"THE PLAYGROUND",Vector3(0,.04,7),70,Color("d6e9d8")).rotation.x = -PI/2

func city() -> void:
	block(Vector3(0,.02,5),Vector3(56,.08,8),Color("3b4c5d"))
	block(Vector3(0,.03,0),Vector3(8,.08,56),Color("3b4c5d"))
	for i in range(-5,6):
		trim(Vector3(i*5,.08,5),Vector3(2,.03,.14),Color("ead8a0"))
		trim(Vector3(0,.09,i*5),Vector3(.14,.03,2),Color("ead8a0"))
	for x in [-1,1]:
		for z in [-1,1]:
			block(Vector3(x*16,.1,z*17),Vector3(21,.2,19),Color("d4cdb6"))
	for i in range(7):
		var x = -22+i*7
		if abs(x)<5: continue
		var height = 5+(i%3)*2.5
		var b = block(Vector3(x,height/2,-23),Vector3(5.5,height,6),[Color("bfbdad"),Color("88aeb0"),Color("d8a183")][i%3])
		for floor_id in range(int(height/1.5)):
			for window in range(3):
				Art.box(b,Vector3(-1.65+window*1.65,-height/2+1+floor_id*1.5,3.02),Vector3(1.05,.8,.06),Art.material(Color("344e62"),.35))
		Art.box(b,Vector3(0,height/2+.15,0),Vector3(5.9,.3,6.4),Art.material(Color("4a626b")))
	for side in [-1,1]:
		block(Vector3(side*18,1.7,14),Vector3(13,3.4,7),Color("cfbfa1"))
		Art.label(self,"JUICE & CO." if side==1 else "THE ORCHARD",Vector3(side*18,3.0,18),40,Color("ffcb73"))
		for i in range(4): trim(Vector3(side*18-4.5+i*3,1.6,17.53),Vector3(2.3,2.2,.06),Color("355668"))
		trim(Vector3(side*18,3.1,18),Vector3(13,.18,1.6),Color("d96e62"))
	for p in [Vector3(-10,0,-8),Vector3(12,0,-8),Vector3(-9,0,18),Vector3(9,0,18)]: tree(p)
	for x in [-7,7]:
		for z in [-15,0,16]: lamp(Vector3(x,0,z))
	game.spawn_prop("Car",Vector3(9,1,5))
	game.spawn_prop("Car",Vector3(-12,1,5))
	for i in range(4): game.spawn_prop("Crate",Vector3(19+i%2*1.2,1+i/2,9))
	trampoline(Vector3(-14,0,-10))
	fan(Vector3(20,0,-9))

func factory() -> void:
	for x in range(-5,6): trim(Vector3(x*5,.02,0),Vector3(.06,.04,55),Color("94acac"))
	for z in range(-5,6): trim(Vector3(0,.02,z*5),Vector3(55,.04,.06),Color("94acac"))
	for x in [-25,25]:
		for z in [-20,-5,10,24]:
			block(Vector3(x,4,z),Vector3(.8,8,.8),Color("eebc65"))
			Art.box(self,Vector3(x,8.2,z),Vector3(1.8,.3,1.8),Art.material(Color("334d60")))
	for z in [-20,-5,10,24]: trim(Vector3(0,8,z),Vector3(51,.5,.5),Color("345466"))
	for i in range(4):
		var x = -21+i*4.2
		var pos = Vector3(x,2.2,-19)
		Art.cylinder(self,pos,1.5,4.4,Art.material(Color("8eabb4"),.7))
		Art.sphere(self,pos+Vector3(0,2.2,0),Vector3(1.5,.6,1.5),Art.material(Color("aac4c9"),.65))
		Art.cylinder(self,pos+Vector3(0,0,1.48),.18,3.1,Art.glow([Color("f7c469"),Color("8be5b8"),Color("ff8eaa"),Color("b09bff")][i]))
		Art.label(self,"0%d / JUICE"%i,pos+Vector3(0,1,1.52),24)
		block(pos,Vector3(2.8,4.4,2.8),Color("829da7")).get_child(0).visible = false
	for x in [-12,12]:
		block(Vector3(x,.7,1),Vector3(3,1.4,18),Color("2c4559"))
		for i in range(20):
			var roller = Art.cylinder(self,Vector3(x,1.5,-7+i*.8),.13,2.9,Art.material(Color("92aaaf"),.75))
			roller.rotation.z = PI/2
		belt_zones.append(Vector3(x,2.1,1))
		for i in range(3): game.spawn_prop("Barrel",Vector3(x,2.9,-5+i*4))
	var pipe = Art.cylinder(self,Vector3(0,5,-19),.35,44,Art.material(Color("dca864"),.4))
	pipe.rotation.z = PI/2
	trampoline(Vector3(20,0,14))
	fan(Vector3(-19,0,15))
	moving_platform(Vector3(19,2,-7))
	block(Vector3(20,3.8,-9),Vector3(7,.4,8),Color("d8ac67"))
	Art.label(self,"JUICE WORKS / LAB 03",Vector3(0,6.7,-24),64,Color("a2eed9"))
	game.spawn_prop("Car",Vector3(7,1,16))

func moving_platform(pos: Vector3) -> void:
	var body = AnimatableBody3D.new()
	body.position = pos
	body.set_meta("origin",pos)
	add_child(body)
	Art.box(body,Vector3.ZERO,Vector3(3,.3,3),Art.material(Color("ebba6a")))
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(3,.3,3)
	col.shape = shape
	body.add_child(col)
	movers.append(body)

func _physics_process(delta: float) -> void:
	clock += delta
	for m in movers: m.position = m.get_meta("origin")+Vector3(0,sin(clock*.65)*1.5,0)
	for f in fans: f.rotate_y(delta*12)
	for body in get_tree().get_nodes_in_group("saveable"):
		if not is_instance_valid(body) or body.freeze: continue
		for zone in bounce_zones:
			if abs(body.global_position.x-zone.x)<1.5 and abs(body.global_position.z-zone.z)<1.5 and body.global_position.y<zone.y+.4 and body.linear_velocity.y<1:
				if body is FruitNPC: body.knock(Vector3.ZERO)
				body.linear_velocity.y = 12
				game.sound("jump",zone,1.4)
		for zone in wind_zones:
			var p = body.global_position-zone
			if abs(p.x)<1.4 and abs(p.z)<1.4 and p.y<7: body.apply_central_force(Vector3.UP*body.mass*22)
		for zone in belt_zones:
			var p = body.global_position-zone
			if abs(p.x)<1.6 and abs(p.z)<9 and abs(p.y)<1.3: body.apply_central_force(Vector3(0,0,body.mass*9))
