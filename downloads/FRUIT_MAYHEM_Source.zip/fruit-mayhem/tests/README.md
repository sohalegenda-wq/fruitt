Integration suite: godot --headless --path . -- --smoke-test

The suite runs the actual game scene and Godot physics server. It verifies all ten character factories, four articulated limbs each, ragdoll and recovery, freeze/X-Ray, save/load round-trip, actual camera ray hits, the freeze/size/bubble/teleport/cannon/shockwave devices, movement/jump input, three map factories, every menu page, graphics/weather settings, and the challenge victory condition. Success prints TEST: PASS and exits 0; assertions or script errors indicate failure.

To verify the exported pack independently from the source directory:

godot --headless --main-pack exports/FRUIT_MAYHEM.exe -- --smoke-test

This uses the Linux Godot runtime to load the embedded resource pack; it does not establish that the Windows executable starts under Windows. Visual checks require a non-headless renderer. The --tour option starts a graphical arena tour; --capture is a development-only automated gallery capture that writes to /workspace/work.
