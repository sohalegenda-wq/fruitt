param([string]$Godot = "godot")
$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
New-Item -ItemType Directory -Force -Path (Join-Path $projectRoot "exports") | Out-Null
& $Godot --headless --path $projectRoot --editor --import --quit
if ($LASTEXITCODE -ne 0) { throw "Godot asset import failed ($LASTEXITCODE)" }
$target = Join-Path $projectRoot "exports/FRUIT_MAYHEM.exe"
& $Godot --headless --path $projectRoot --export-release "Windows Desktop" $target
if ($LASTEXITCODE -ne 0) { throw "Export failed. Install matching Godot 4.6.3 export templates." }
if (!(Test-Path $target) -or (Get-Item $target).Length -lt 1000000) { throw "EXE is missing or incomplete" }
Get-FileHash $target -Algorithm SHA256
Write-Host "Ready: $target"
