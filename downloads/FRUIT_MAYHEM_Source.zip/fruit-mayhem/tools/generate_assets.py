from PIL import Image
import math, random, wave, struct, os
from pathlib import Path
root=str(Path(__file__).resolve().parents[1] / 'assets')
random.seed(19)
# Seamless authored rind surface, RGB normal map. Tint supplied by fruit materials.
n=128
height=[[0.5+0.14*math.sin(x*math.tau/16)*math.sin(y*math.tau/16)+random.random()*.25 for x in range(n)] for y in range(n)]
im=Image.new('RGB',(n,n)); normal=Image.new('RGB',(n,n))
for y in range(n):
 for x in range(n):
  v=int(195+height[y][x]*58); im.putpixel((x,y),(v,v,v))
  dx=(height[y][(x+1)%n]-height[y][(x-1)%n])*.65; dy=(height[(y+1)%n][x]-height[(y-1)%n][x])*.65
  normal.putpixel((x,y),(int(128-dx*100),int(128-dy*100),248))
im.save(root+'/textures/rind.png'); normal.save(root+'/textures/rind_normal.png')
# Watermelon UV bands, pineapple diamonds.
for name in ['melon','pineapple']:
 im=Image.new('RGB',(256,128))
 for y in range(128):
  for x in range(256):
   if name=='melon':
    f=math.sin(x/256*math.tau*10+0.18*math.sin(y/128*math.tau*4)); c=(34,90,41) if f>.25 else (151,193,66)
   else:
    a=(x+y*2)%32; b=(x-y*2)%32; edge=min(a,32-a,b,32-b)<2; c=(124,84,23) if edge else (245,185+int(10*math.sin(x)),58)
   im.putpixel((x,y),c)
 im.save(root+'/textures/'+name+'.png')
# All sounds synthesized here; no third-party samples.
rate=22050
for name,dur,freq in [('click',.09,850),('jump',.2,300),('impact',.22,100),('juice',.28,450),('voice',.35,500),('freeze',.4,1500),('pulse',.45,150),('step',.07,130),('motor',1,70)]:
 samples=[]
 for i in range(int(rate*dur)):
  t=i/rate; e=(1-t/dur)**2
  f=freq*(1+(.6 if name in ['jump','voice','freeze'] else -.65)*t/dur)
  signal=math.sin(math.tau*f*t)*.45+random.uniform(-1,1)*(.3 if name in ['impact','juice','step'] else .025)
  samples.append(int(max(-1,min(1,signal*e*.45))*32767))
 with wave.open(root+'/audio/'+name+'.wav','w') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(struct.pack('<'+'h'*len(samples),*samples))
# Original calm 16-second marimba-like loop.
notes=[220,277.18,329.63,415.3,369.99,329.63,277.18,246.94]
samples=[]
for i in range(rate*16):
 t=i/rate; beat=int(t*2); local=t%0.5; f=notes[beat%8]
 v=(math.sin(math.tau*f*t)+.25*math.sin(math.tau*f*3*t))*math.exp(-local*8)*.10
 v+=math.sin(math.tau*110*t)*.025
 samples.append(int(v*32767))
with wave.open(root+'/audio/music.wav','w') as w:
 w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(struct.pack('<'+'h'*len(samples),*samples))
